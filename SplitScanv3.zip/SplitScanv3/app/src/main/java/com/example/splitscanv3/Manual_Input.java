package com.example.splitscanv3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Manual_Input extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual__input);

        Button addTransactionbtn = (Button) findViewById(R.id.addTransaction);
        addTransactionbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addTransaction = new Intent(getApplicationContext(), MainActivity.class);

                EditText transactionName = (EditText) findViewById(R.id.transactionName);
                EditText transactionAmount = (EditText) findViewById(R.id.transactionAmount);
                EditText transactionppl = (EditText) findViewById(R.id.transactionNumberPpl);
                EditText transactionpayee = (EditText) findViewById(R.id.Payee);

                String transactionname = transactionName.getText().toString();
                double transactionamount = Integer.parseInt(transactionAmount.getText().toString());
                double numberOfppl = Integer.parseInt(transactionppl.getText().toString());
                String payee = transactionpayee.getText().toString();

                if (payee.equals("Me")) {
                    MainActivity.addToTotalOwed(transactionamount - (transactionamount / numberOfppl));
                    MainActivity.addToAmountToPayMe(transactionamount - (transactionamount / numberOfppl));
                    MainActivity.addToPaymentToMeDescription(transactionname);

                } else {
                    MainActivity.addToTotalDue(transactionamount / numberOfppl);
                    MainActivity.addToAmountToPay(transactionamount / numberOfppl);
                    MainActivity.addToPaymentDescription(transactionname);
                    MainActivity.addToPersonToPay(payee);
                }


                startActivity(addTransaction);
            }
        });
    }
}
