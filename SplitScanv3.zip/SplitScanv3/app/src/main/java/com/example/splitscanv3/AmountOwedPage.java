package com.example.splitscanv3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.List;

public class AmountOwedPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amount_owed_page);

        ListView amountOwedList = (ListView) findViewById(R.id.amountOwedList);
    }
}
