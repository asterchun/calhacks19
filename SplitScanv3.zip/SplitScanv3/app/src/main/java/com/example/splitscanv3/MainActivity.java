package com.example.splitscanv3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static double amount_Due = 0;
    private static double amount_Owed = 0;
    private static ArrayList<String> personToPay = new ArrayList<String>();
    private static ArrayList<String> paymentDescription = new ArrayList<String>();
    private static ArrayList<Double> amountToPay = new ArrayList<Double>();
    private static ArrayList<String> paymentToMeDescription = new ArrayList<String>();
    private static ArrayList<Double> amountToPayMe = new ArrayList<Double>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView totalOwed = (TextView) findViewById(R.id.totalOwed);
        TextView totalDue = (TextView) findViewById(R.id.totalDue);
        totalOwed.setText(getTotalOwed()+ "");
        totalDue.setText(getTotalDue() + "");

        Button manualTransactionBtn = (Button) findViewById(R.id.manualTransaction);
        manualTransactionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newPage = new Intent(getApplicationContext(), Manual_Input.class);
                startActivity(newPage);
            }
        });

        Button cameraTransactionBtn = (Button) findViewById(R.id.cameraTransaction);
        cameraTransactionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newPage = new Intent(getApplicationContext(), Camera_input.class);
                startActivity(newPage);
            }
        });

        Button amountDuebtn = (Button) findViewById(R.id.amountDueList);
        amountDuebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newPage = new Intent(getApplicationContext(), AmountDuePage.class);
                startActivity(newPage);
            }
        });

        Button amountOwedbtn = (Button) findViewById(R.id.amountOwed);
        amountOwedbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newPage = new Intent(getApplicationContext(), AmountOwedPage.class);
                startActivity(newPage);
            }
        });

        Button settingsBtn = (Button) findViewById(R.id.settingsButton);
        settingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newPage = new Intent(getApplicationContext(), Settings.class);
                startActivity(newPage);
            }
        });
    }

    public static double getTotalDue() {
        return amount_Due;
    }

    public static double getTotalOwed() {
        return amount_Owed;
    }

    public static void addToTotalDue(double x) {
        amount_Due += x;
    }

    public static void addToTotalOwed(double x) {
        amount_Owed += x;
    }

    public static ArrayList<String> getPersonToPay() {return personToPay;}

    public static void addToPersonToPay(String x) {
        personToPay.add(x);
    }

    public static ArrayList<String> getPaymentDescription() {return paymentDescription;}

    public static void addToPaymentDescription(String x) {
        paymentDescription.add(x);
    }

    public static ArrayList<Double> getAmountToPay() {return amountToPay;}

    public static void addToAmountToPay(Double x) {
        amountToPay.add(x);
    }

    public static ArrayList<String> getPaymentToMeDescription() {return paymentToMeDescription;}

    public static void addToPaymentToMeDescription(String x) {
        paymentToMeDescription.add(x);
    }

    public static ArrayList<Double> getAmountToPayMe() {return amountToPayMe;}

    public static void addToAmountToPayMe(Double x) {
        amountToPayMe.add(x);
    }

}
